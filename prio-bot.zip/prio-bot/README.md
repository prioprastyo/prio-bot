# whatsapp-caliph-bot
BOT WHATSAPP TERMUX

# Ketik %menu/%help



### Cara Installnya
```
> termux-setup-storage
> apt update -y
> apt upgrade -y
> pkg install git -y
> pkg install unzip -y
> git clone https://github.com/Caliph71/caliph-bot
> cd whatsapp-caliph-bot
> unzip caliph-bot.zip
> ls
> cd caliph-bot
> ls
> pkg install ffmpeg -y
> pkg install wget -y
> pkg install nodejs -y
> pkg install tesseract -y
> npm i -g cwebp
> npm i -g ytdl
> npm i node-tesseract-ocr
> npm i
> npm i got
> node index.js
```

## Features

| CALIPH BOT    |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Magernulis                       |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Anime                            |                     |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Info                             |
|       ✅       | Donate                           |
|       ✅       | Simi-Simi
|       ✅       | ocr

### Donate
* [`Saweria`](https://saweria.co/Caliph123)

### Join
* [`Whatsapp`](https://bit.ly/GC_BotLovers)


